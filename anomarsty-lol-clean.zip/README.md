# anomarsty.lol — Clean Store Portal [GOLD EDITION]

This is the NEW clean repo for anomarsty.lol — RSTY misspelling intentional — all money lives here.

## Canon LOCKED (matches anomartsy.xyz)
- Palette: #000000 bg, #0A0A10 void, #00eaff cyan xyz, #ff00c8 magenta in-build, #d8ae55 GOLD = store + Anom Coin
- Typography: Space Mono Bold + Inter
- Breathing: 3.2s / 3.6s / 3.9s / 4.1s never synced
- Translation: bling=Anom Coin, fubar=AO, NO bouncers only moderators patrol + Ambassadors steward
- Economy: EVERYTHING THEY DO EARNS ANOM COIN — 10 AC = $1 building currency — digital-only — PayPal/Stripe/CashApp — xyz free no checkout, lol all money

## What this repo is
Built on top of ANOMS-Originals-Store backend:
- products/ = product definitions (112+ assets)
- mockups/ = T-shirt, sticker sheets, digital previews
- listings/ = SEO titles/descriptions/tags
- pricing/ = tiers, bundle discounts, promo
- integrations/ = Shopify configs, payment gateway, fulfillment APIs
- automation/ = inventory alerts, order processing, sync scripts
- seed-products.mjs = COMPLETE PRODUCT CAT
- PET GEAR INTEGRATION checkpoint = Moonberry Hop Mount Race +20 AC

Categories in this clean frontend:
- Terrain, Sky, Structures, Decorations, Textures, Mood Patches, Pet Gear, Apparel
- Each: AC price + $ price, +Earn badge, Buy with PayPal/Stripe/CashApp
- Cart shows earned vs spent AC (e.g., earned 240 AC building -> spend 120 AC)

## Pipeline (from ANOMS-Originals-Store README)
Asset created in anom-artsy -> Brand approved via ANOMS-Brand-Kit -> Product defined -> Mockup -> Listing -> Price set -> Published via integrations/automation

## Domains
- anomartsy.xyz = Library World homeworld free — shows all worlds — NO checkout
- anomarsty.lol = THIS REPO — store — all checkout — 112+ assets digital-only
- Library World center links back to xyz, lol is outer gold orbit

## Deploy
Self-contained index.html — no build step needed.
GitHub -> Settings -> Pages -> Source: Deploy from main / root -> Custom domain: anomarsty.lol

Also includes worlds.html = epic AO Universe world map (video version) — embed on both xyz and lol.

Never use word glitch. Always Anomoly with O.
